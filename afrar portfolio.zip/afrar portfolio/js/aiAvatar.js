/**
 * aiAvatar.js
 * Temporary AI Introduction & Miniature Avatar Module for Mohammad Afrar.
 * Active as a placeholder concept before Mohammad uploads his real video.
 * Automatically steps down/minimizes when the authentic video is uploaded.
 */

class AIAvatarModule {
  constructor() {
    this.container = document.getElementById('ai-avatar-card');
    this.speechSynthesis = window.speechSynthesis || null;
    this.isSpeaking = false;
    this.synthUtterance = null;
    this.animFrameId = null;
    this.hasRealVideo = false;

    this.init();
  }

  init() {
    this.bindEvents();
    this.initWaveCanvas();
  }

  bindEvents() {
    const playSpeechBtn = document.getElementById('ai-speak-btn');
    if (playSpeechBtn) {
      playSpeechBtn.addEventListener('click', () => this.toggleSpeech());
    }

    const toggleFallbackBtn = document.getElementById('toggle-ai-fallback-btn');
    if (toggleFallbackBtn) {
      toggleFallbackBtn.addEventListener('click', () => this.toggleFallbackVisibility());
    }
  }

  handleRealVideoUploaded(hasReal) {
    this.hasRealVideo = hasReal;
    const aiCard = document.getElementById('ai-avatar-card');
    const aiFallbackDrawer = document.getElementById('ai-fallback-drawer');
    const aiBanner = document.getElementById('ai-temporary-banner');

    if (hasReal) {
      // Real video is primary. Hide temporary banner and convert AI avatar into an optional collapsed fallback
      if (aiBanner) aiBanner.style.display = 'none';
      if (aiCard) aiCard.classList.add('ai-minimized-mode');
      if (aiFallbackDrawer) aiFallbackDrawer.style.display = 'block';
    } else {
      // No real video yet. Show Temporary AI introduction prominently
      if (aiBanner) aiBanner.style.display = 'inline-flex';
      if (aiCard) {
        aiCard.classList.remove('ai-minimized-mode');
        aiCard.style.display = 'block';
      }
      if (aiFallbackDrawer) aiFallbackDrawer.style.display = 'none';
    }
  }

  toggleFallbackVisibility() {
    const aiCard = document.getElementById('ai-avatar-card');
    const chevron = document.getElementById('ai-drawer-chevron');
    if (!aiCard) return;

    if (aiCard.style.display === 'none' || !aiCard.style.display) {
      aiCard.style.display = 'block';
      if (chevron) chevron.className = 'fas fa-chevron-up';
    } else {
      aiCard.style.display = 'none';
      if (chevron) chevron.className = 'fas fa-chevron-down';
      this.stopSpeech();
    }
  }

  toggleSpeech() {
    if (this.isSpeaking) {
      this.stopSpeech();
    } else {
      this.startSpeech();
    }
  }

  startSpeech() {
    const playSpeechBtn = document.getElementById('ai-speak-btn');
    const speechScript = "Hello and welcome! I am the AI Introduction avatar for Mohammad Afrar. Mohammad is an innovative engineer specializing in embedded systems, robotics, and full-stack software. Feel free to explore his Fire Detection and Extinguishing Robot and Smart Alcohol Detection Vehicle projects below, or upload Mohammad's authentic video above to view his real introduction!";

    if (!('speechSynthesis' in window)) {
      window.appToast?.show('Speech synthesis not supported in this browser.', 'info');
      this.simulateSpeechVisualizer();
      return;
    }

    window.speechSynthesis.cancel();
    this.synthUtterance = new SpeechSynthesisUtterance(speechScript);
    this.synthUtterance.rate = 1.02;
    this.synthUtterance.pitch = 1.0;

    // Pick natural English voice if available
    const voices = window.speechSynthesis.getVoices();
    const naturalVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('David')));
    if (naturalVoice) this.synthUtterance.voice = naturalVoice;

    this.synthUtterance.onstart = () => {
      this.isSpeaking = true;
      if (playSpeechBtn) {
        playSpeechBtn.innerHTML = '<i class="fas fa-pause"></i> Pause AI Voice Intro';
        playSpeechBtn.classList.add('speaking');
      }
      if (avatarImg) avatarImg.classList.add('avatar-speaking');
      this.startWaveAnimation();
    };

    this.synthUtterance.onend = () => {
      this.stopSpeech();
    };

    this.synthUtterance.onerror = () => {
      this.stopSpeech();
    };

    window.speechSynthesis.speak(this.synthUtterance);
  }

  stopSpeech() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
    const playSpeechBtn = document.getElementById('ai-speak-btn');
    const avatarImg = document.getElementById('ai-avatar-portrait');
    if (playSpeechBtn) {
      playSpeechBtn.innerHTML = '<i class="fas fa-play"></i> Play AI Voice Introduction';
      playSpeechBtn.classList.remove('speaking');
    }
    if (avatarImg) avatarImg.classList.remove('avatar-speaking');
    this.stopWaveAnimation();
  }

  initWaveCanvas() {
    this.canvas = document.getElementById('ai-voice-wave');
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.drawIdleWave();
  }

  drawIdleWave() {
    if (!this.ctx || !this.canvas) return;
    const ctx = this.ctx;
    const w = this.canvas.width = this.canvas.offsetWidth || 300;
    const h = this.canvas.height = 48;

    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    for (let x = 0; x < w; x += 10) {
      const y = h / 2 + Math.sin(x * 0.05) * 3;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  startWaveAnimation() {
    let offset = 0;
    const animate = () => {
      if (!this.isSpeaking || !this.ctx || !this.canvas) return;
      const ctx = this.ctx;
      const w = this.canvas.width = this.canvas.offsetWidth || 300;
      const h = this.canvas.height = 48;

      ctx.clearRect(0, 0, w, h);
      
      // Gradient stroke
      const gradient = ctx.createLinearGradient(0, 0, w, 0);
      gradient.addColorStop(0, '#6366f1');
      gradient.addColorStop(0.5, '#06b6d4');
      gradient.addColorStop(1, '#10b981');

      ctx.strokeStyle = gradient;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, h / 2);

      for (let x = 0; x < w; x += 4) {
        const freq1 = Math.sin((x + offset) * 0.08) * 14;
        const freq2 = Math.cos((x - offset * 1.5) * 0.04) * 8;
        const y = h / 2 + freq1 + freq2;
        ctx.lineTo(x, y);
      }
      ctx.stroke();

      offset += 3;
      this.animFrameId = requestAnimationFrame(animate);
    };

    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    animate();
  }

  stopWaveAnimation() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    this.drawIdleWave();
  }

  simulateSpeechVisualizer() {
    this.isSpeaking = true;
    this.startWaveAnimation();
    setTimeout(() => {
      this.stopSpeech();
    }, 6000);
  }
}

// Instantiate on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.aiAvatarModule = new AIAvatarModule();
});
