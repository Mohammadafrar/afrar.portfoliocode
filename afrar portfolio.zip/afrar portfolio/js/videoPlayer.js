/**
 * videoPlayer.js
 * Custom Ultra-Polished Video Player for Mohammad Afrar's Personal Introduction Video.
 * Handles Responsive Aspect Ratios, Picture-in-Picture, Seeking, Poster generation,
 * Fullscreen, Volume & Playback Speed, and seamless state management.
 */

class IntroVideoPlayer {
  constructor(options = {}) {
    this.container = document.getElementById('intro-video-container');
    this.videoElement = null;
    this.currentVideoData = null;
    this.aspectRatio = '16:9'; // '16:9' or '9:16'
    this.isMuted = false;
    this.isPlaying = false;
    this.init();
  }

  async init() {
    this.bindGlobalEvents();
    // Check if there is already a saved video in IndexedDB on page load
    await this.loadSavedVideo();
  }

  bindGlobalEvents() {
    // Listen for drop & file select in upload zones
    const uploadInput = document.getElementById('intro-video-file-input');
    if (uploadInput) {
      uploadInput.addEventListener('change', (e) => this.handleFileInput(e));
    }

    const modalUploadInput = document.getElementById('modal-video-file-input');
    if (modalUploadInput) {
      modalUploadInput.addEventListener('change', (e) => this.handleFileInput(e));
    }

    // Modal triggers
    const triggerUploadBtns = document.querySelectorAll('.trigger-intro-upload');
    triggerUploadBtns.forEach(btn => {
      btn.addEventListener('click', () => this.openUploadModal());
    });

    const replaceBtn = document.getElementById('replace-intro-video-btn');
    if (replaceBtn) {
      replaceBtn.addEventListener('click', () => this.openUploadModal());
    }

    const removeBtn = document.getElementById('remove-intro-video-btn');
    if (removeBtn) {
      removeBtn.addEventListener('click', () => this.confirmRemoveVideo());
    }

    // Drag & Drop Setup
    this.setupDropZones();
  }

  setupDropZones() {
    const dropZones = document.querySelectorAll('.video-dropzone');
    dropZones.forEach(zone => {
      ['dragenter', 'dragover'].forEach(eventName => {
        zone.addEventListener(eventName, (e) => {
          e.preventDefault();
          e.stopPropagation();
          zone.classList.add('drag-active');
        }, false);
      });

      ['dragleave', 'drop'].forEach(eventName => {
        zone.addEventListener(eventName, (e) => {
          e.preventDefault();
          e.stopPropagation();
          zone.classList.remove('drag-active');
        }, false);
      });

      zone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files && files.length > 0) {
          this.processVideoFile(files[0]);
        }
      }, false);
    });
  }

  async loadSavedVideo() {
    try {
      const savedVideo = await window.videoStorageService.getIntroVideo();
      if (savedVideo && savedVideo.url) {
        this.currentVideoData = savedVideo;
        this.aspectRatio = savedVideo.aspectRatio || '16:9';
        this.renderUploadedState(savedVideo);
        // Inform AI Avatar module to step down
        if (window.aiAvatarModule) {
          window.aiAvatarModule.handleRealVideoUploaded(true);
        }
      } else {
        this.renderEmptyState();
        if (window.aiAvatarModule) {
          window.aiAvatarModule.handleRealVideoUploaded(false);
        }
      }
    } catch (err) {
      console.error('Failed to load saved intro video:', err);
      this.renderEmptyState();
    }
  }

  openUploadModal() {
    const modal = document.getElementById('upload-video-modal');
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  closeUploadModal() {
    const modal = document.getElementById('upload-video-modal');
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
      const progressContainer = document.getElementById('upload-progress-container');
      if (progressContainer) progressContainer.style.display = 'none';
    }
  }

  handleFileInput(e) {
    const file = e.target.files[0];
    if (file) {
      this.processVideoFile(file);
      e.target.value = ''; // Reset input
    }
  }

  async processVideoFile(file) {
    // Validate format: MP4, WebM, MOV (video/quicktime)
    const validExtensions = ['.mp4', '.webm', '.mov'];
    const fileName = file.name.toLowerCase();
    const isValidExt = validExtensions.some(ext => fileName.endsWith(ext));
    const isValidMime = file.type.startsWith('video/') || file.type === 'video/quicktime';

    if (!isValidExt && !isValidMime) {
      window.appToast?.show('Unsupported format! Please upload an MP4, WebM, or MOV video.', 'error');
      return;
    }

    // Show upload progress simulation in modal or UI
    this.openUploadModal();
    const progressContainer = document.getElementById('upload-progress-container');
    const progressBar = document.getElementById('upload-progress-bar');
    const progressText = document.getElementById('upload-progress-text');
    const progressFileName = document.getElementById('upload-file-name');

    if (progressContainer && progressBar && progressText) {
      progressContainer.style.display = 'block';
      progressFileName.textContent = `${file.name} (${VideoStorageService.formatBytes(file.size)})`;
      progressBar.style.width = '0%';
      progressText.textContent = 'Processing and indexing video... 0%';

      // Simulate smooth progress bar for high UX feel
      for (let i = 10; i <= 90; i += 20) {
        await new Promise(r => setTimeout(r, 120));
        progressBar.style.width = `${i}%`;
        progressText.textContent = `Optimizing video buffer... ${i}%`;
      }
    }

    try {
      // Capture poster snapshot
      const thumbnailInfo = await VideoStorageService.captureVideoThumbnail(file, 1.0);
      
      // Auto-detect optimal aspect ratio if height > width
      let detectedAspect = '16:9';
      if (thumbnailInfo.videoHeight && thumbnailInfo.videoWidth) {
        if (thumbnailInfo.videoHeight > thumbnailInfo.videoWidth) {
          detectedAspect = '9:16';
        }
      }

      const metadata = {
        poster: thumbnailInfo.posterUrl,
        duration: thumbnailInfo.duration,
        aspectRatio: detectedAspect,
        width: thumbnailInfo.videoWidth,
        height: thumbnailInfo.videoHeight
      };

      // Save to IndexedDB persistent storage
      const savedRecord = await window.videoStorageService.saveIntroVideo(file, metadata);
      this.currentVideoData = savedRecord;
      this.aspectRatio = detectedAspect;

      if (progressBar && progressText) {
        progressBar.style.width = '100%';
        progressText.textContent = 'Saved to persistent storage! 100%';
        await new Promise(r => setTimeout(r, 300));
      }

      this.closeUploadModal();
      this.renderUploadedState(savedRecord);

      // Notify AI Avatar module
      if (window.aiAvatarModule) {
        window.aiAvatarModule.handleRealVideoUploaded(true);
      }

      window.appToast?.show('Mohammad Afrar\'s Introduction Video successfully uploaded & saved!', 'success');
    } catch (err) {
      console.error('Error processing video:', err);
      window.appToast?.show('Failed to save video. Please try again.', 'error');
      if (progressContainer) progressContainer.style.display = 'none';
    }
  }

  renderEmptyState() {
    const meetTitle = document.getElementById('meet-section-title');
    const meetBadge = document.getElementById('meet-section-badge');
    if (meetTitle) meetTitle.textContent = 'Meet Mohammad';
    if (meetBadge) meetBadge.innerHTML = '<span class="pulse-dot"></span> Upload Introduction Pending';

    const uploadArea = document.getElementById('intro-upload-zone');
    const playerArea = document.getElementById('intro-player-zone');
    
    if (uploadArea) uploadArea.style.display = 'block';
    if (playerArea) playerArea.style.display = 'none';
  }

  renderUploadedState(videoData) {
    const meetTitle = document.getElementById('meet-section-title');
    const meetBadge = document.getElementById('meet-section-badge');
    if (meetTitle) meetTitle.textContent = 'My Introduction';
    if (meetBadge) {
      meetBadge.innerHTML = '<i class="fas fa-check-circle text-emerald"></i> Official Real Introduction Video';
      meetBadge.className = 'section-badge verified-badge';
    }

    const uploadArea = document.getElementById('intro-upload-zone');
    const playerArea = document.getElementById('intro-player-zone');
    
    if (uploadArea) uploadArea.style.display = 'none';
    if (playerArea) playerArea.style.display = 'block';

    // Update video metadata labels
    const metaSize = document.getElementById('video-meta-size');
    const metaFormat = document.getElementById('video-meta-format');
    const metaDate = document.getElementById('video-meta-date');

    if (metaSize) metaSize.textContent = VideoStorageService.formatBytes(videoData.size);
    if (metaFormat) metaFormat.textContent = (videoData.type || 'video/mp4').toUpperCase().replace('VIDEO/', '');
    if (metaDate) metaDate.textContent = new Date(videoData.uploadedAt || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    // Setup Custom Video Player Elements
    this.mountVideoPlayer(videoData);
  }

  mountVideoPlayer(videoData) {
    const playerWrapper = document.getElementById('custom-video-wrapper');
    if (!playerWrapper) return;

    playerWrapper.className = `custom-video-wrapper aspect-${this.aspectRatio.replace(':', '-')}`;

    // Clear previous video
    playerWrapper.innerHTML = `
      <video id="main-intro-video" playsinline preload="metadata" poster="${videoData.poster || 'assets/images/mohammad_afrar_real.png'}">
        <source src="${videoData.url}" type="${videoData.type || 'video/mp4'}">
        Your browser does not support HTML5 video playback.
      </video>

      <div class="video-overlay-play" id="video-overlay-play-btn" title="Click to play">
        <div class="play-pulse-ring"></div>
        <button class="big-play-btn" aria-label="Play Introduction Video">
          <i class="fas fa-play"></i>
        </button>
      </div>

      <div class="custom-video-controls" id="custom-video-controls">
        <!-- Progress Bar -->
        <div class="video-progress-container" id="video-progress-container">
          <div class="video-progress-buffer" id="video-progress-buffer"></div>
          <div class="video-progress-bar" id="video-progress-bar">
            <div class="video-progress-thumb"></div>
          </div>
          <div class="video-time-tooltip" id="video-time-tooltip">00:00</div>
        </div>

        <div class="controls-row">
          <!-- Left Controls -->
          <div class="controls-left">
            <button class="ctrl-btn" id="ctrl-play-btn" title="Play/Pause (Space)">
              <i class="fas fa-play"></i>
            </button>
            <div class="volume-container">
              <button class="ctrl-btn" id="ctrl-volume-btn" title="Mute/Unmute">
                <i class="fas fa-volume-up"></i>
              </button>
              <input type="range" class="volume-slider" id="ctrl-volume-slider" min="0" max="1" step="0.05" value="1">
            </div>
            <div class="time-display">
              <span id="ctrl-current-time">0:00</span> / <span id="ctrl-duration">0:00</span>
            </div>
          </div>

          <!-- Right Controls -->
          <div class="controls-right">
            <!-- Aspect Ratio Switcher -->
            <button class="ctrl-btn aspect-btn" id="ctrl-aspect-btn" title="Toggle 16:9 / 9:16 Aspect Ratio">
              <span id="aspect-label">${this.aspectRatio}</span>
            </button>
            <!-- Speed Selector -->
            <div class="speed-dropdown">
              <button class="ctrl-btn speed-btn" id="ctrl-speed-btn" title="Playback Speed">
                <span id="speed-label">1x</span>
              </button>
              <div class="speed-menu" id="speed-menu">
                <div class="speed-opt" data-speed="0.75">0.75x</div>
                <div class="speed-opt active" data-speed="1.0">1.0x (Normal)</div>
                <div class="speed-opt" data-speed="1.25">1.25x</div>
                <div class="speed-opt" data-speed="1.5">1.5x</div>
                <div class="speed-opt" data-speed="2.0">2.0x</div>
              </div>
            </div>
            <!-- PiP -->
            <button class="ctrl-btn" id="ctrl-pip-btn" title="Picture in Picture">
              <i class="fas fa-external-link-alt"></i>
            </button>
            <!-- Fullscreen -->
            <button class="ctrl-btn" id="ctrl-fullscreen-btn" title="Fullscreen (F)">
              <i class="fas fa-expand"></i>
            </button>
          </div>
        </div>
      </div>
    `;

    this.videoElement = document.getElementById('main-intro-video');
    this.attachPlayerEventListeners();
  }

  attachPlayerEventListeners() {
    if (!this.videoElement) return;

    const video = this.videoElement;
    const playBtn = document.getElementById('ctrl-play-btn');
    const overlayPlay = document.getElementById('video-overlay-play-btn');
    const volumeBtn = document.getElementById('ctrl-volume-btn');
    const volumeSlider = document.getElementById('ctrl-volume-slider');
    const progressContainer = document.getElementById('video-progress-container');
    const progressBar = document.getElementById('video-progress-bar');
    const bufferBar = document.getElementById('video-progress-buffer');
    const currentTimeEl = document.getElementById('ctrl-current-time');
    const durationEl = document.getElementById('ctrl-duration');
    const fullscreenBtn = document.getElementById('ctrl-fullscreen-btn');
    const pipBtn = document.getElementById('ctrl-pip-btn');
    const aspectBtn = document.getElementById('ctrl-aspect-btn');
    const speedBtn = document.getElementById('ctrl-speed-btn');
    const speedMenu = document.getElementById('speed-menu');
    const timeTooltip = document.getElementById('video-time-tooltip');

    const togglePlay = () => {
      if (video.paused || video.ended) {
        video.play();
      } else {
        video.pause();
      }
    };

    // Play / Pause triggers
    if (playBtn) playBtn.addEventListener('click', togglePlay);
    if (overlayPlay) overlayPlay.addEventListener('click', togglePlay);
    video.addEventListener('click', togglePlay);

    video.addEventListener('play', () => {
      this.isPlaying = true;
      if (playBtn) playBtn.innerHTML = '<i class="fas fa-pause"></i>';
      if (overlayPlay) overlayPlay.classList.add('hidden');
    });

    video.addEventListener('pause', () => {
      this.isPlaying = false;
      if (playBtn) playBtn.innerHTML = '<i class="fas fa-play"></i>';
      if (overlayPlay) overlayPlay.classList.remove('hidden');
    });

    video.addEventListener('ended', () => {
      this.isPlaying = false;
      if (playBtn) playBtn.innerHTML = '<i class="fas fa-redo"></i>';
      if (overlayPlay) overlayPlay.classList.remove('hidden');
    });

    // Time & Progress update
    const formatTime = (seconds) => {
      if (isNaN(seconds) || seconds < 0) return '0:00';
      const m = Math.floor(seconds / 60);
      const s = Math.floor(seconds % 60);
      return `${m}:${s < 10 ? '0' : ''}${s}`;
    };

    video.addEventListener('loadedmetadata', () => {
      if (durationEl) durationEl.textContent = formatTime(video.duration);
    });

    video.addEventListener('timeupdate', () => {
      if (currentTimeEl) currentTimeEl.textContent = formatTime(video.currentTime);
      if (progressBar && video.duration) {
        const percent = (video.currentTime / video.duration) * 100;
        progressBar.style.width = `${percent}%`;
      }
    });

    video.addEventListener('progress', () => {
      if (video.buffered.length > 0 && bufferBar && video.duration) {
        const bufferedEnd = video.buffered.end(video.buffered.length - 1);
        const bufferPercent = (bufferedEnd / video.duration) * 100;
        bufferBar.style.width = `${bufferPercent}%`;
      }
    });

    // Seek scrub
    if (progressContainer) {
      let isSeeking = false;
      const seek = (e) => {
        const rect = progressContainer.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        if (video.duration) {
          video.currentTime = pos * video.duration;
        }
      };

      progressContainer.addEventListener('mousedown', (e) => {
        isSeeking = true;
        seek(e);
      });

      window.addEventListener('mousemove', (e) => {
        if (isSeeking) seek(e);
      });

      window.addEventListener('mouseup', () => {
        isSeeking = false;
      });

      // Hover Tooltip
      progressContainer.addEventListener('mousemove', (e) => {
        const rect = progressContainer.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        if (timeTooltip && video.duration) {
          timeTooltip.style.left = `${pos * 100}%`;
          timeTooltip.textContent = formatTime(pos * video.duration);
          timeTooltip.style.opacity = '1';
        }
      });

      progressContainer.addEventListener('mouseleave', () => {
        if (timeTooltip) timeTooltip.style.opacity = '0';
      });
    }

    // Volume & Mute
    if (volumeSlider) {
      volumeSlider.addEventListener('input', (e) => {
        video.volume = e.target.value;
        video.muted = (video.volume === 0);
        this.updateVolumeIcon();
      });
    }

    if (volumeBtn) {
      volumeBtn.addEventListener('click', () => {
        video.muted = !video.muted;
        if (video.muted) {
          if (volumeSlider) volumeSlider.value = 0;
        } else {
          if (video.volume === 0) video.volume = 0.8;
          if (volumeSlider) volumeSlider.value = video.volume;
        }
        this.updateVolumeIcon();
      });
    }

    // Aspect Ratio Switcher (16:9 / 9:16)
    if (aspectBtn) {
      aspectBtn.addEventListener('click', () => {
        this.aspectRatio = (this.aspectRatio === '16:9') ? '9:16' : '16:9';
        const playerWrapper = document.getElementById('custom-video-wrapper');
        if (playerWrapper) {
          playerWrapper.className = `custom-video-wrapper aspect-${this.aspectRatio.replace(':', '-')}`;
        }
        const label = document.getElementById('aspect-label');
        if (label) label.textContent = this.aspectRatio;
        // Update stored metadata
        if (this.currentVideoData) {
          this.currentVideoData.aspectRatio = this.aspectRatio;
          window.videoStorageService.saveIntroVideo(this.currentVideoData.blob, {
            ...this.currentVideoData,
            aspectRatio: this.aspectRatio
          });
        }
      });
    }

    // Speed Selector
    if (speedBtn && speedMenu) {
      speedBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        speedMenu.classList.toggle('show');
      });

      document.querySelectorAll('.speed-opt').forEach(opt => {
        opt.addEventListener('click', (e) => {
          e.stopPropagation();
          const speed = parseFloat(opt.dataset.speed);
          video.playbackRate = speed;
          document.getElementById('speed-label').textContent = `${speed}x`;
          document.querySelectorAll('.speed-opt').forEach(o => o.classList.remove('active'));
          opt.classList.add('active');
          speedMenu.classList.remove('show');
        });
      });

      document.addEventListener('click', () => {
        speedMenu.classList.remove('show');
      });
    }

    // PiP
    if (pipBtn) {
      pipBtn.addEventListener('click', async () => {
        try {
          if (document.pictureInPictureElement) {
            await document.exitPictureInPicture();
          } else if (document.pictureInPictureEnabled) {
            await video.requestPictureInPicture();
          }
        } catch (err) {
          console.warn('PiP error:', err);
        }
      });
    }

    // Fullscreen
    if (fullscreenBtn) {
      fullscreenBtn.addEventListener('click', () => {
        const playerWrapper = document.getElementById('custom-video-wrapper');
        if (!document.fullscreenElement) {
          if (playerWrapper.requestFullscreen) {
            playerWrapper.requestFullscreen();
          } else if (video.webkitEnterFullscreen) {
            video.webkitEnterFullscreen();
          }
        } else {
          if (document.exitFullscreen) {
            document.exitFullscreen();
          }
        }
      });
    }
  }

  updateVolumeIcon() {
    const video = this.videoElement;
    const volumeBtn = document.getElementById('ctrl-volume-btn');
    if (!video || !volumeBtn) return;

    if (video.muted || video.volume === 0) {
      volumeBtn.innerHTML = '<i class="fas fa-volume-mute text-danger"></i>';
    } else if (video.volume < 0.5) {
      volumeBtn.innerHTML = '<i class="fas fa-volume-down"></i>';
    } else {
      volumeBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
    }
  }

  async confirmRemoveVideo() {
    const isConfirmed = confirm('Are you sure you want to remove Mohammad Afrar\'s introduction video? This will clear the video from persistent storage.');
    if (!isConfirmed) return;

    try {
      await window.videoStorageService.deleteIntroVideo();
      this.currentVideoData = null;
      this.renderEmptyState();
      if (window.aiAvatarModule) {
        window.aiAvatarModule.handleRealVideoUploaded(false);
      }
      window.appToast?.show('Introduction video removed.', 'info');
    } catch (err) {
      console.error('Error removing video:', err);
      window.appToast?.show('Failed to remove video.', 'error');
    }
  }
}

// Instantiate on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.introVideoPlayer = new IntroVideoPlayer();
});
