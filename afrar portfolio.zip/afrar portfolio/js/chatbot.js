/**
 * chatbot.js
 * Interactive Intelligent AI Chatbot for Mohammad Afrar's Portfolio.
 * Answers all visitor queries about Mohammad's background, education, projects,
 * personal introduction video system, tech stack, and contact details.
 */

class PortfolioChatbot {
  constructor() {
    this.widget = document.getElementById('ai-chatbot-widget');
    this.messagesContainer = document.getElementById('chat-messages-body');
    this.inputField = document.getElementById('chat-user-input');
    this.sendBtn = document.getElementById('chat-send-btn');
    this.toggleBtn = document.getElementById('chatbot-launcher-btn');
    this.closeBtn = document.getElementById('chat-close-btn');
    this.suggestionsContainer = document.getElementById('chat-suggestions');
    this.isOpen = false;

    this.portfolioKnowledge = {
      name: "Mohammad Afrar",
      title: "Computer Science & Engineering (CSE) Student & Innovator",
      college: "Adichunchanagiri Institute of Technology (AIT), Chikkamagaluru",
      puc: "St. Joseph Pre-University College (12th Class)",
      school: "Malnad Education Society (10th Class)",
      phone: "+91 9110296253",
      email: "mohammadafrar.cse@gmail.com",
      github: "https://github.com/Mohammadafrar/Mohammad-Afrar",
      linkedin: "https://www.linkedin.com/in/mohd-afrar-067260378?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      location: "Chikkamagaluru, Karnataka, India",
      skills: ["Robotics & Actuators", "Embedded C/C++", "Microcontrollers & Arduino", "IoT Gas & Flame Sensors", "Full-Stack Web Development", "HTML5/CSS3/JavaScript", "IndexedDB", "Python", "Cloud & Git"],
      projects: [
        {
          name: "Fire Detection & Extinguishing Robot",
          desc: "An autonomous intelligent firefighting rover equipped with multi-directional optical flame sensors, obstacle-avoidance sonar, and an automated high-pressure water pump nozzle mechanism for swift fire suppression."
        },
        {
          name: "Smart Alcohol Detection & Ignition Lock Vehicle",
          desc: "An automotive safety and anti-drunk driving embedded platform using MQ-3 breathalyzer gas sensors to evaluate Blood Alcohol Concentration (BAC) and trigger automatic engine ignition lockouts with real-time status alerts."
        }
      ],
      introVideoSystem: "The portfolio features a dedicated 'Meet Mohammad' section with direct client-side MP4/WebM/MOV video upload stored persistently in IndexedDB without third-party YouTube ads. Before uploading, a temporary interactive AI avatar introduces Afrar, and once uploaded, Afrar's real video becomes primary with responsive playback controls and 16:9 / 9:16 aspect ratio support."
    };

    this.init();
  }

  init() {
    this.bindEvents();
    this.renderSuggestions();
  }

  bindEvents() {
    if (this.toggleBtn) {
      this.toggleBtn.addEventListener('click', () => this.toggleChat());
    }

    if (this.closeBtn) {
      this.closeBtn.addEventListener('click', () => this.toggleChat(false));
    }

    if (this.sendBtn && this.inputField) {
      this.sendBtn.addEventListener('click', () => this.handleSendMessage());
      this.inputField.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.handleSendMessage();
        }
      });
    }

    // Quick suggestion chips
    const quickChips = document.querySelectorAll('.chat-chip');
    quickChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const text = chip.getAttribute('data-query') || chip.textContent;
        this.askQuestion(text);
      });
    });
  }

  toggleChat(forceState = null) {
    this.isOpen = (forceState !== null) ? forceState : !this.isOpen;
    if (this.widget) {
      if (this.isOpen) {
        this.widget.classList.add('chat-open');
        this.inputField?.focus();
        // Hide notification badge once opened
        const badge = document.getElementById('chatbot-unread-dot');
        if (badge) badge.style.display = 'none';
      } else {
        this.widget.classList.remove('chat-open');
      }
    }
  }

  renderSuggestions() {
    const suggestions = [
      "Tell me about Mohammad Afrar",
      "Where did Afrar study? (Education)",
      "What are Afrar's projects?",
      "How can I contact Afrar?",
      "Tell me about the Fire Extinguishing Robot",
      "How does the Introduction Video work?"
    ];

    if (!this.suggestionsContainer) return;
    this.suggestionsContainer.innerHTML = suggestions.map(s => `
      <button class="chat-chip" data-query="${s}">${s}</button>
    `).join('');

    this.suggestionsContainer.querySelectorAll('.chat-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        this.askQuestion(btn.getAttribute('data-query'));
      });
    });
  }

  askQuestion(questionText) {
    if (!this.isOpen) this.toggleChat(true);
    this.appendMessage(questionText, 'user');
    this.showTypingIndicator();

    setTimeout(() => {
      const response = this.generateResponse(questionText);
      this.removeTypingIndicator();
      this.appendMessage(response, 'bot');
    }, 600);
  }

  handleSendMessage() {
    if (!this.inputField) return;
    const text = this.inputField.value.trim();
    if (!text) return;

    this.inputField.value = '';
    this.appendMessage(text, 'user');
    this.showTypingIndicator();

    setTimeout(() => {
      const response = this.generateResponse(text);
      this.removeTypingIndicator();
      this.appendMessage(response, 'bot');
    }, 650);
  }

  appendMessage(content, sender = 'bot') {
    if (!this.messagesContainer) return;

    const msgEl = document.createElement('div');
    msgEl.className = `chat-bubble chat-${sender}`;

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (sender === 'bot') {
      msgEl.innerHTML = `
        <div class="chat-avatar bot-avatar"><i class="fas fa-robot"></i></div>
        <div class="chat-text-wrapper">
          <div class="chat-author">Afrar AI Assistant</div>
          <div class="chat-content">${content}</div>
          <div class="chat-time">${timestamp}</div>
        </div>
      `;
    } else {
      msgEl.innerHTML = `
        <div class="chat-text-wrapper">
          <div class="chat-content">${this.escapeHtml(content)}</div>
          <div class="chat-time">${timestamp}</div>
        </div>
      `;
    }

    this.messagesContainer.appendChild(msgEl);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }

  showTypingIndicator() {
    this.removeTypingIndicator();
    const typing = document.createElement('div');
    typing.id = 'chat-typing-indicator';
    typing.className = 'chat-bubble chat-bot typing-bubble';
    typing.innerHTML = `
      <div class="chat-avatar bot-avatar"><i class="fas fa-robot"></i></div>
      <div class="chat-text-wrapper">
        <div class="typing-dots">
          <span></span><span></span><span></span>
        </div>
      </div>
    `;
    this.messagesContainer.appendChild(typing);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }

  removeTypingIndicator() {
    const typing = document.getElementById('chat-typing-indicator');
    if (typing) typing.remove();
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  generateResponse(query) {
    const q = query.toLowerCase();

    // 1. Education & Colleges
    if (q.includes('education') || q.includes('study') || q.includes('college') || q.includes('school') || q.includes('ait') || q.includes('pu') || q.includes('10th') || q.includes('12th') || q.includes('malnad') || q.includes('joseph') || q.includes('degree')) {
      return `
        <strong>🎓 Mohammad Afrar's Educational Background:</strong><br><br>
        • <strong>Engineering / Graduation:</strong> Computer Science & Engineering (CSE) Student at <strong>Adichunchanagiri Institute of Technology (AIT), Chikkamagaluru</strong>.<br>
        • <strong>12th Class (PUC):</strong> Studied at <strong>St. Joseph Pre-University College</strong>.<br>
        • <strong>10th Class (SSLC):</strong> Completed schooling at <strong>Malnad Education Society (MES)</strong>.
      `;
    }

    // 2. Who is Mohammad Afrar / Bio
    if (q.includes('who') || q.includes('about') || q.includes('afrar') || q.includes('introduce') || q.includes('bio') || q.includes('profile')) {
      return `
        <strong>👋 Meet Mohammad Afrar:</strong><br><br>
        Mohammad Afrar is a Computer Science and Engineering (CSE) student at <strong>AIT College Chikkamagaluru</strong>. He is passionate about Embedded Systems, Robotics, IoT Sensors, and Full-Stack Web Development.<br><br>
        He is known for developing hardware projects like the <em>Fire Detection & Extinguishing Robot</em> and the <em>Smart Alcohol Detection Vehicle</em>, as well as high-performance modern web platforms.
      `;
    }

    // 3. Contact Details / Phone / Email / Socials
    if (q.includes('contact') || q.includes('phone') || q.includes('number') || q.includes('email') || q.includes('gmail') || q.includes('linkedin') || q.includes('github') || q.includes('reach') || q.includes('call') || q.includes('whatsapp')) {
      return `
        <strong>📬 Contact Mohammad Afrar Directly:</strong><br><br>
        • <strong>Phone / Call / WhatsApp:</strong> <a href="tel:9110296253" class="chat-link">📞 +91 9110296253</a><br>
        • <strong>Gmail:</strong> <a href="mailto:mohammadafrar.cse@gmail.com" class="chat-link">✉️ mohammadafrar.cse@gmail.com</a><br>
        • <strong>LinkedIn:</strong> <a href="https://www.linkedin.com/in/mohd-afrar-067260378?utm_source=share_via&utm_content=profile&utm_medium=member_android" target="_blank" rel="noopener" class="chat-link"><i class="fab fa-linkedin"></i> linkedin.com/in/mohd-afrar-067260378</a><br>
        • <strong>GitHub:</strong> <a href="https://github.com/Mohammadafrar/Mohammad-Afrar" target="_blank" rel="noopener" class="chat-link"><i class="fab fa-github"></i> github.com/Mohammadafrar/Mohammad-Afrar</a><br>
        • <strong>Location:</strong> Chikkamagaluru, Karnataka, India
      `;
    }

    // 4. Projects (Fire Robot & Alcohol Detection Vehicle)
    if (q.includes('project') || q.includes('fire') || q.includes('robot') || q.includes('robo') || q.includes('alcohol') || q.includes('vehicle') || q.includes('car') || q.includes('extinguish')) {
      if (q.includes('fire') || q.includes('extinguish')) {
        return `
          <strong>🔥 Fire Detection & Extinguishing Robot:</strong><br><br>
          An autonomous intelligent firefighting rover designed by Mohammad Afrar. It features optical flame sensor arrays, obstacle-avoidance sonar, microcontroller logic, and an automated high-pressure water pump nozzle mechanism for swift fire suppression.<br><br>
          <em>Tech used:</em> Robotics, Microcontrollers, Flame Sensors, Servo Actuators, IoT Telemetry.
        `;
      }
      if (q.includes('alcohol') || q.includes('vehicle')) {
        return `
          <strong>🚗 Smart Alcohol Detection & Ignition Lock Vehicle:</strong><br><br>
          An intelligent automotive safety and anti-drunk driving platform. It utilizes MQ-3 breathalyzer gas sensors to evaluate driver Blood Alcohol Concentration (BAC) and trigger automatic engine ignition lockouts with real-time status alerts.<br><br>
          <em>Tech used:</em> Embedded Systems, MQ-3 Gas Sensor, Relay Interlock, Hardware C++, Automotive Safety.
        `;
      }
      return `
        <strong>🛠️ Mohammad Afrar's Key Engineering Projects:</strong><br><br>
        1. <strong>Fire Detection & Extinguishing Robot:</strong> Autonomous rover with optical flame detection and automated water extinguishing pump nozzle.<br><br>
        2. <strong>Smart Alcohol Detection Vehicle:</strong> MQ-3 breathalyzer safety system with automatic engine ignition relay interlock.<br><br>
        You can check them out in the <a href="#projects" class="chat-link">Projects & Demos</a> section!
      `;
    }

    // 5. Personal Introduction Video System
    if (q.includes('video') || q.includes('intro') || q.includes('youtube') || q.includes('storage') || q.includes('indexeddb') || q.includes('upload')) {
      return `
        <strong>🎥 Real Personal Introduction Video System:</strong><br><br>
        • <strong>Authentic Video Focus:</strong> Mohammad's personal introduction is powered by his genuine uploaded video (MP4, WebM, MOV) with zero third-party YouTube ads.<br>
        • <strong>Persistent Vault:</strong> The video is stored locally in browser <strong>IndexedDB</strong>, preserving high definition across page refreshes.<br>
        • <strong>Player Features:</strong> Custom controls, speed selection, volume, scrubber with time tooltip, and 16:9 / 9:16 aspect ratio switcher.<br>
        • <strong>AI Avatar Fallback:</strong> Before upload, an interactive AI avatar based on Afrar's photo welcomes you. Once Afrar uploads his real video, it automatically becomes primary!
      `;
    }

    // 6. Skills & Tech Stack
    if (q.includes('skill') || q.includes('tech') || q.includes('programming') || q.includes('language') || q.includes('stack') || q.includes('c++') || q.includes('arduino')) {
      return `
        <strong>💻 Mohammad Afrar's Technical Stack:</strong><br><br>
        • <strong>Embedded & Hardware:</strong> Embedded C/C++, Microcontrollers (Arduino/ESP32), MQ-3 Sensors, Flame Sensors, Relays & Actuators.<br>
        • <strong>Software & Web:</strong> JavaScript (ES6+), TypeScript, HTML5/CSS3, Python, Node.js, REST APIs.<br>
        • <strong>Storage & Tools:</strong> IndexedDB, Git/GitHub, Docker, Linux, IoT Telemetry.
      `;
    }

    // 7. Greetings
    if (q.includes('hi') || q.includes('hello') || q.includes('hey') || q.includes('good morning') || q.includes('good evening') || q.includes('namaste')) {
      return `
        Hello there! 😊 Welcome to Mohammad Afrar's portfolio! I am his AI assistant. How can I help you today? You can ask me about his education at AIT Chikkamagaluru, his robotics projects, or how to get in touch with him!
      `;
    }

    // 8. Default intelligent fallback
    return `
      Thanks for your question! Mohammad Afrar is a Computer Science (CSE) student at <strong>AIT College Chikkamagaluru</strong>, skilled in Embedded Systems, Robotics, and Web Engineering.<br><br>
      Feel free to ask about:<br>
      • <strong>His Education</strong> (AIT Chikkamagaluru, St. Joseph PU College, MES)<br>
      • <strong>His Projects</strong> (Fire Extinguishing Robot, Alcohol Detection Vehicle)<br>
      • <strong>His Contact Details</strong> (Phone: +91 9110296253, Email, LinkedIn, GitHub)<br>
      • <strong>His Personal Video System</strong>
    `;
  }
}

// Instantiate on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.portfolioChatbot = new PortfolioChatbot();
});
