/**
 * videoStorage.js
 * Persistent Client-side Video Storage Architecture for Mohammad Afrar's Portfolio.
 * Uses IndexedDB for multi-megabyte binary persistence (MP4, WebM, MOV) across page reloads.
 * Completely isolates Personal Introduction Video from Project Video demos.
 */

class VideoStorageService {
  constructor() {
    this.dbName = 'MohammadAfrar_PortfolioDB';
    this.dbVersion = 1;
    this.db = null;
    this.readyPromise = this.initDB();
  }

  /**
   * Initializes the IndexedDB database with separate object stores for:
   * 1. 'intro_video' (Mohammad Afrar's primary personal introduction video)
   * 2. 'project_videos' (Dedicated showcase demonstrations & presentations)
   */
  async initDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        console.warn('IndexedDB not supported. Falling back to session memory.');
        resolve(null);
        return;
      }

      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        // Personal Intro Store
        if (!db.objectStoreNames.contains('intro_video')) {
          db.createObjectStore('intro_video', { keyPath: 'id' });
        }
        // Project Demo Videos Store (Completely separate from Intro Video)
        if (!db.objectStoreNames.contains('project_videos')) {
          db.createObjectStore('project_videos', { keyPath: 'projectId' });
        }
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        resolve(this.db);
      };

      request.onerror = (event) => {
        console.error('IndexedDB open error:', event.target.error);
        resolve(null);
      };
    });
  }

  /**
   * Checks if persistent storage is supported and available in the user's browser.
   */
  async isPersistentStorageAvailable() {
    await this.readyPromise;
    return !!this.db;
  }

  /**
   * Save Mohammad Afrar's Personal Introduction Video to IndexedDB.
   * @param {File|Blob} file 
   * @param {Object} metadata (name, size, type, duration, poster, aspectRatio)
   */
  async saveIntroVideo(file, metadata = {}) {
    await this.readyPromise;
    if (!this.db) {
      // Fallback: Create Object URL
      const fallbackUrl = URL.createObjectURL(file);
      sessionStorage.setItem('has_session_intro_video', 'true');
      return {
        id: 'primary_intro',
        url: fallbackUrl,
        name: file.name || 'Mohammad_Afrar_Intro.mp4',
        type: file.type || 'video/mp4',
        size: file.size,
        updatedAt: new Date().toISOString(),
        isSessionOnly: true,
        ...metadata
      };
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['intro_video'], 'readwrite');
      const store = transaction.objectStore('intro_video');

      const record = {
        id: 'primary_intro',
        blob: file,
        name: file.name || 'Mohammad_Afrar_Introduction.mp4',
        type: file.type || 'video/mp4',
        size: file.size,
        poster: metadata.poster || null,
        aspectRatio: metadata.aspectRatio || '16:9',
        duration: metadata.duration || 0,
        uploadedAt: new Date().toISOString()
      };

      const request = store.put(record);

      request.onsuccess = () => {
        // Generate Object URL for immediate playback
        const videoUrl = URL.createObjectURL(file);
        resolve({
          ...record,
          url: videoUrl,
          isSessionOnly: false
        });
      };

      request.onerror = (event) => {
        reject(new Error('Failed to save video to persistent database: ' + event.target.error));
      };
    });
  }

  /**
   * Retrieves Mohammad Afrar's saved Personal Introduction Video.
   */
  async getIntroVideo() {
    await this.readyPromise;
    if (!this.db) return null;

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['intro_video'], 'readonly');
      const store = transaction.objectStore('intro_video');
      const request = store.get('primary_intro');

      request.onsuccess = () => {
        const record = request.result;
        if (record && record.blob) {
          const videoUrl = URL.createObjectURL(record.blob);
          resolve({
            ...record,
            url: videoUrl
          });
        } else {
          resolve(null);
        }
      };

      request.onerror = (event) => {
        console.error('Error fetching intro video:', event.target.error);
        resolve(null);
      };
    });
  }

  /**
   * Removes Mohammad Afrar's saved Personal Introduction Video.
   */
  async deleteIntroVideo() {
    await this.readyPromise;
    if (!this.db) return true;

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['intro_video'], 'readwrite');
      const store = transaction.objectStore('intro_video');
      const request = store.delete('primary_intro');

      request.onsuccess = () => resolve(true);
      request.onerror = (event) => reject(event.target.error);
    });
  }

  /**
   * Save a Project Demo / Presentation Video or external embed link.
   * Completely independent from personal introduction video storage.
   */
  async saveProjectVideo(projectId, videoData) {
    await this.readyPromise;
    if (!this.db) return null;

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction(['project_videos'], 'readwrite');
      const store = transaction.objectStore('project_videos');

      const record = {
        projectId,
        type: videoData.type, // 'upload' or 'youtube'
        blob: videoData.blob || null,
        url: videoData.url || null,
        title: videoData.title || 'Project Demonstration',
        name: videoData.name || '',
        updatedAt: new Date().toISOString()
      };

      const request = store.put(record);
      request.onsuccess = () => resolve(record);
      request.onerror = (event) => reject(event.target.error);
    });
  }

  /**
   * Retrieves a project demo video by projectId.
   */
  async getProjectVideo(projectId) {
    await this.readyPromise;
    if (!this.db) return null;

    return new Promise((resolve) => {
      const transaction = this.db.transaction(['project_videos'], 'readonly');
      const store = transaction.objectStore('project_videos');
      const request = store.get(projectId);

      request.onsuccess = () => {
        const record = request.result;
        if (record && record.blob) {
          record.objectUrl = URL.createObjectURL(record.blob);
        }
        resolve(record || null);
      };

      request.onerror = () => resolve(null);
    });
  }

  /**
   * Helper: Format bytes to human readable string (KB, MB, GB).
   */
  static formatBytes(bytes, decimals = 2) {
    if (!bytes || bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  /**
   * Generates a poster thumbnail snapshot from a given video blob or file.
   */
  static async captureVideoThumbnail(videoBlobOrFile, seekTime = 1.0) {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.muted = true;
      video.playsInline = true;

      const url = URL.createObjectURL(videoBlobOrFile);
      video.src = url;

      video.onloadedmetadata = () => {
        video.currentTime = Math.min(seekTime, video.duration > 0 ? video.duration / 2 : 0.5);
      };

      video.onseeked = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth || 1280;
          canvas.height = video.videoHeight || 720;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          URL.revokeObjectURL(url);
          resolve({
            posterUrl: dataUrl,
            duration: video.duration,
            videoWidth: video.videoWidth,
            videoHeight: video.videoHeight
          });
        } catch (err) {
          URL.revokeObjectURL(url);
          resolve({ posterUrl: null, duration: video.duration || 0 });
        }
      };

      video.onerror = () => {
        URL.revokeObjectURL(url);
        resolve({ posterUrl: null, duration: 0 });
      };
    });
  }

  /**
   * Storage backend connection configuration info for external deployment
   * Clearly outlines production cloud connectors without leaking credentials.
   */
  static getStorageArchitectureInfo() {
    return {
      currentEngine: 'IndexedDB (Browser Client-Side Persistent Binary Vault)',
      capacity: 'Multi-Gigabyte Persistent Quota (Persistent Origin)',
      supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime', '.mov', '.mp4', '.webm'],
      cloudConnectors: {
        guide: 'To sync Mohammad Afrar\'s uploaded intro video with a custom cloud backend, implement a secure presigned URL endpoint (AWS S3, Supabase Storage, or Cloudflare R2). No API secrets are embedded on the client.',
        endpointsAvailable: ['S3 / R2 Direct Presigned PUT', 'Supabase Storage / Firebase Storage Stream', 'Custom REST Video Ingestion Server']
      }
    };
  }
}

// Global Singleton
window.videoStorageService = new VideoStorageService();
