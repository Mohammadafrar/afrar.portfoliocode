/**
 * app.js
 * Main Application Controller for Mohammad Afrar's Portfolio.
 * Manages UI animations, Toast notifications, Modal workflows, Theme switches, and Interactive Elements.
 */

class ToastManager {
  constructor() {
    this.container = document.getElementById('toast-container');
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toast-container';
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  }

  show(message, type = 'info', duration = 4000) {
    const toast = document.createElement('div');
    toast.className = `toast-item toast-${type}`;
    
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    toast.innerHTML = `
      <div class="toast-icon"><i class="fas fa-${icon}"></i></div>
      <div class="toast-message">${message}</div>
      <button class="toast-close" aria-label="Close Notification">&times;</button>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    });

    this.container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
      }
    }, duration);
  }
}

class App {
  constructor() {
    window.appToast = new ToastManager();
    this.initNavbar();
    this.initHeroTyping();
    this.initModals();
    this.initStorageInfoModal();
    this.initContactForm();
    this.initThemeToggle();
  }

  initNavbar() {
    const header = document.querySelector('.site-header');
    const mobileToggle = document.getElementById('mobile-menu-toggle');
    const navMenu = document.getElementById('nav-menu');

    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        header?.classList.add('scrolled');
      } else {
        header?.classList.remove('scrolled');
      }
    });

    if (mobileToggle && navMenu) {
      mobileToggle.addEventListener('click', () => {
        navMenu.classList.toggle('nav-open');
        mobileToggle.classList.toggle('is-active');
      });

      navMenu.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
          navMenu.classList.remove('nav-open');
          mobileToggle.classList.remove('is-active');
        });
      });
    }
  }

  initHeroTyping() {
    const typingEl = document.getElementById('hero-typing-text');
    if (!typingEl) return;

    const phrases = [
      'Robotics & Embedded Systems Developer',
      'IoT & Smart Vehicle Safety Innovator',
      'Full-Stack Software Engineer',
      'Cloud & Distributed Systems Architect'
    ];

    let phraseIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    const type = () => {
      const currentPhrase = phrases[phraseIndex];
      if (isDeleting) {
        typingEl.textContent = currentPhrase.substring(0, charIndex - 1);
        charIndex--;
      } else {
        typingEl.textContent = currentPhrase.substring(0, charIndex + 1);
        charIndex++;
      }

      let speed = isDeleting ? 40 : 80;

      if (!isDeleting && charIndex === currentPhrase.length) {
        speed = 2000;
        isDeleting = true;
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        phraseIndex = (phraseIndex + 1) % phrases.length;
        speed = 500;
      }

      setTimeout(type, speed);
    };

    type();
  }

  initModals() {
    // Close modal on backdrop click or close button
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('active');
          document.body.style.overflow = '';
        }
      });
    });

    document.querySelectorAll('.modal-close-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal-overlay');
        if (modal) {
          modal.classList.remove('active');
          document.body.style.overflow = '';
        }
      });
    });
  }

  initStorageInfoModal() {
    const storageBtn = document.getElementById('open-storage-info-btn');
    const storageModal = document.getElementById('storage-architecture-modal');
    if (storageBtn && storageModal) {
      storageBtn.addEventListener('click', () => {
        storageModal.classList.add('active');
      });
    }
  }

  initContactForm() {
    const form = document.getElementById('contact-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('contact-name')?.value;
      const email = document.getElementById('contact-email')?.value;
      const msg = document.getElementById('contact-message')?.value;

      if (!name || !email || !msg) {
        window.appToast.show('Please complete all required fields.', 'warning');
        return;
      }

      window.appToast.show(`Thank you, ${name}! Your message has been received. Mohammad Afrar will get back to you shortly.`, 'success');
      form.reset();
    });
  }

  initThemeToggle() {
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (!themeBtn) return;

    const currentTheme = localStorage.getItem('afrar_portfolio_theme') || 'dark';
    document.documentElement.setAttribute('data-theme', currentTheme);
    this.updateThemeIcon(currentTheme);

    themeBtn.addEventListener('click', () => {
      const active = document.documentElement.getAttribute('data-theme') || 'dark';
      const nextTheme = active === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', nextTheme);
      localStorage.setItem('afrar_portfolio_theme', nextTheme);
      this.updateThemeIcon(nextTheme);
    });
  }

  updateThemeIcon(theme) {
    const btn = document.getElementById('theme-toggle-btn');
    if (!btn) return;
    if (theme === 'light') {
      btn.innerHTML = '<i class="fas fa-moon"></i>';
      btn.title = 'Switch to Dark Mode';
    } else {
      btn.innerHTML = '<i class="fas fa-sun"></i>';
      btn.title = 'Switch to Light Mode';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.app = new App();
});
