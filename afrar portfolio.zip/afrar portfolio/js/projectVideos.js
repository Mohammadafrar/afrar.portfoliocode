/**
 * projectVideos.js
 * Independent Project Demonstration & Presentation Video Manager.
 * Handles uploaded project videos (MP4, WebM, MOV) and optional project YouTube embeds.
 * Strictly decoupled from Mohammad Afrar's Personal Introduction Video.
 */

class ProjectVideoManager {
  constructor() {
    this.projects = [
      {
        id: 'proj-fire-extinguish-robo',
        title: 'Fire Detection & Extinguishing Robot',
        desc: 'Autonomous intelligent firefighting rover equipped with multi-directional flame sensors, obstacle-avoidance sonar, and an automated high-pressure water pump nozzle mechanism for swift fire suppression.',
        tags: ['Robotics', 'Microcontrollers', 'Flame Sensors', 'Servo Actuators', 'IoT Telemetry'],
        hasUploadedDemo: false,
        videoType: 'poster', // 'upload', 'youtube', 'poster'
        demoUrl: null,
        youtubeId: null,
        posterImg: 'assets/images/fire_robo_poster.jpg'
      },
      {
        id: 'proj-alcohol-detection-vehicle',
        title: 'Smart Alcohol Detection & Ignition Lock Vehicle',
        desc: 'Automotive safety and anti-drunk driving embedded platform using MQ-3 breathalyzer sensors to evaluate Blood Alcohol Concentration (BAC) and trigger automatic engine ignition lockouts with real-time status alerts.',
        tags: ['Embedded Systems', 'MQ-3 Gas Sensor', 'Relay Interlock', 'Automotive Safety', 'Hardware C++'],
        hasUploadedDemo: false,
        videoType: 'poster',
        demoUrl: null,
        youtubeId: null,
        posterImg: 'assets/images/alcohol_detection_poster.jpg'
      }
    ];

    this.activeProjectId = null;
    this.init();
  }

  async init() {
    this.bindEvents();
    await this.loadProjectVideosFromDB();
    this.renderProjectCards();
  }

  bindEvents() {
    // Project upload modal triggers
    const modal = document.getElementById('project-video-modal');
    const closeBtn = document.getElementById('close-proj-modal');
    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => modal.classList.remove('active'));
    }

    // Tab buttons in project modal
    document.querySelectorAll('.proj-tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.proj-tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.proj-tab-pane').forEach(p => p.classList.remove('active'));
        
        btn.classList.add('active');
        const target = btn.dataset.tab;
        const pane = document.getElementById(target);
        if (pane) pane.classList.add('active');
      });
    });

    // Handle project video file upload
    const projFileInput = document.getElementById('proj-video-file-input');
    if (projFileInput) {
      projFileInput.addEventListener('change', (e) => this.handleProjectFileUpload(e));
    }

    // Handle project YouTube link embed save
    const saveYtBtn = document.getElementById('save-proj-youtube-btn');
    if (saveYtBtn) {
      saveYtBtn.addEventListener('click', () => this.handleYoutubeLinkSubmit());
    }
  }

  async loadProjectVideosFromDB() {
    for (const proj of this.projects) {
      const saved = await window.videoStorageService.getProjectVideo(proj.id);
      if (saved) {
        proj.videoType = saved.type;
        proj.demoUrl = saved.objectUrl || saved.url;
        proj.youtubeId = saved.youtubeId || null;
      }
    }
  }

  renderProjectCards() {
    const container = document.getElementById('projects-grid');
    if (!container) return;

    container.innerHTML = this.projects.map(proj => `
      <div class="project-card" data-project-id="${proj.id}">
        <div class="project-media-wrapper" id="media-wrap-${proj.id}">
          ${this.renderProjectMedia(proj)}
        </div>

        <div class="project-info">
          <div class="project-tags">
            ${proj.tags.map(t => `<span class="proj-tag">${t}</span>`).join('')}
          </div>
          <h3 class="project-title">${proj.title}</h3>
          <p class="project-desc">${proj.desc}</p>
          
          <div class="project-actions">
            <button class="btn btn-outline-glow btn-sm" onclick="window.projectVideoManager.openProjectModal('${proj.id}')">
              <i class="fas fa-video"></i> Configure Demo Video
            </button>
            <a href="#contact" class="btn btn-primary btn-sm">
              <i class="fas fa-arrow-right"></i> View Specs
            </a>
          </div>
        </div>
      </div>
    `).join('');
  }

  renderProjectMedia(proj) {
    if (proj.videoType === 'upload' && proj.demoUrl) {
      return `
        <div class="project-video-player">
          <video controls playsinline class="responsive-video" poster="${proj.posterImg}">
            <source src="${proj.demoUrl}">
          </video>
          <div class="media-type-badge"><i class="fas fa-file-video"></i> Uploaded Demo Video</div>
        </div>
      `;
    } else if (proj.videoType === 'youtube' && proj.youtubeId) {
      return `
        <div class="project-video-player iframe-container">
          <iframe 
            src="https://www.youtube.com/embed/${proj.youtubeId}" 
            title="${proj.title} Demo Video" 
            frameborder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowfullscreen>
          </iframe>
          <div class="media-type-badge yt-badge"><i class="fab fa-youtube"></i> Project Demo (External)</div>
        </div>
      `;
    } else {
      return `
        <div class="project-poster-wrapper">
          <img src="${proj.posterImg}" alt="${proj.title}" class="project-poster-img" />
          <div class="poster-overlay">
            <button class="btn-play-demo" onclick="window.projectVideoManager.openProjectModal('${proj.id}')">
              <i class="fas fa-play"></i> Add / Play Demo Video
            </button>
          </div>
        </div>
      `;
    }
  }

  openProjectModal(projectId) {
    this.activeProjectId = projectId;
    const proj = this.projects.find(p => p.id === projectId);
    const modal = document.getElementById('project-video-modal');
    const titleEl = document.getElementById('modal-proj-title');
    
    if (titleEl && proj) {
      titleEl.textContent = proj.title;
    }
    if (modal) {
      modal.classList.add('active');
    }
  }

  async handleProjectFileUpload(e) {
    const file = e.target.files[0];
    if (!file || !this.activeProjectId) return;

    try {
      const record = {
        type: 'upload',
        blob: file,
        name: file.name,
        title: file.name
      };

      await window.videoStorageService.saveProjectVideo(this.activeProjectId, record);
      
      const proj = this.projects.find(p => p.id === this.activeProjectId);
      if (proj) {
        proj.videoType = 'upload';
        proj.demoUrl = URL.createObjectURL(file);
      }

      this.renderProjectCards();
      document.getElementById('project-video-modal')?.classList.remove('active');
      window.appToast?.show('Project Demonstration Video uploaded and attached successfully!', 'success');
    } catch (err) {
      console.error('Error saving project video:', err);
      window.appToast?.show('Could not save project video.', 'error');
    }
  }

  async handleYoutubeLinkSubmit() {
    const input = document.getElementById('proj-yt-url-input');
    const url = input ? input.value.trim() : '';
    if (!url || !this.activeProjectId) return;

    // Extract YouTube ID
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    const youtubeId = (match && match[2].length === 11) ? match[2] : null;

    if (!youtubeId) {
      window.appToast?.show('Invalid YouTube URL. Please enter a valid YouTube project demo link.', 'error');
      return;
    }

    try {
      const record = {
        type: 'youtube',
        url: url,
        youtubeId: youtubeId,
        title: 'YouTube Project Demo'
      };

      await window.videoStorageService.saveProjectVideo(this.activeProjectId, record);

      const proj = this.projects.find(p => p.id === this.activeProjectId);
      if (proj) {
        proj.videoType = 'youtube';
        proj.youtubeId = youtubeId;
      }

      this.renderProjectCards();
      document.getElementById('project-video-modal')?.classList.remove('active');
      if (input) input.value = '';
      window.appToast?.show('Project demo YouTube link connected successfully!', 'success');
    } catch (err) {
      console.error('Error saving project video embed:', err);
    }
  }
}

// Instantiate on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.projectVideoManager = new ProjectVideoManager();
});
